-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2025 at 06:37 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `briodata`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `Bsno` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `add1` varchar(80) NOT NULL,
  `add2` varchar(80) NOT NULL,
  `city` varchar(30) NOT NULL,
  `pincode` int(8) NOT NULL,
  `state` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `mobileno` int(12) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`Bsno`, `name`, `add1`, `add2`, `city`, `pincode`, `state`, `country`, `mobileno`, `email`) VALUES
(3, 'BRIOSOFT', 'AKOTA', 'AKOTA', 'VADODARA', 390017, 'GUJARAT', 'INDIA', 2147483647, 'brio3@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `Bsno` int(11) NOT NULL,
  `Item` varchar(255) NOT NULL,
  `Codeno` varchar(50) NOT NULL,
  `Idesc` text NOT NULL,
  `Unit` varchar(10) NOT NULL,
  `Rate` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`Bsno`, `Item`, `Codeno`, `Idesc`, `Unit`, `Rate`) VALUES
(1, 'ttt', 'tt', 'tt', 'tty', 677.00),
(2, 'brio', 'hhj', 'iuo', 'jj', 967.00),
(3, 'jjj', 'jjj', 'jjj', 'jj', 111.00),
(4, 'hhh', 'hh', 'yyy', 'NOC', 2374.00),
(5, 'kkk', 'kkk', 'uu', 'huu', 798.00),
(7, 'BRIO PRODUCT V V 8.10', 'BS123', 'SOFTWARE FOR TESTING', 'NOS', 15000.00);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `BSno` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`BSno`, `username`, `password`) VALUES
(1, 'briosoft', 'brio@123');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `BSno` int(10) NOT NULL,
  `Ordno` int(80) NOT NULL,
  `Ordate` date NOT NULL,
  `pname` varchar(10) NOT NULL,
  `sr` int(19) NOT NULL,
  `Item` int(80) NOT NULL,
  `Idesc` int(80) NOT NULL,
  `unit` int(5) NOT NULL,
  `Quantity` int(12) NOT NULL,
  `rate` int(12) NOT NULL,
  `amount` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `somst`
--

CREATE TABLE `somst` (
  `Bsno` int(11) NOT NULL,
  `Ordno` int(11) NOT NULL,
  `Orddt` date NOT NULL,
  `Sname` varchar(255) NOT NULL,
  `Sr` int(11) NOT NULL,
  `Item` varchar(255) NOT NULL,
  `Idesc` text DEFAULT NULL,
  `Unit` varchar(10) DEFAULT NULL,
  `Quantity` double NOT NULL DEFAULT 0,
  `Rate` double NOT NULL DEFAULT 0,
  `Amount` double NOT NULL DEFAULT 0,
  `Ordval` double NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `somst`
--

INSERT INTO `somst` (`Bsno`, `Ordno`, `Orddt`, `Sname`, `Sr`, `Item`, `Idesc`, `Unit`, `Quantity`, `Rate`, `Amount`, `Ordval`) VALUES
(1, 4, '2025-03-13', 'vrund ', 1, 'rrr', 'rr', 'rr', 45, 77, 3465, 3465),
(2, 5, '2025-03-13', 'bhakti', 1, 'brio', 'iuo', 'jj', 2, 967, 1934, 1934),
(3, 9, '2025-03-13', 'BRIO SOFT', 1, 'BRIO PRODUCT V V 8.10', 'SOFTWARE FOR MFG..', 'NOS', 2, 15000, 30000, 30000),
(4, 1, '2025-03-13', 'bhakti', 1, 'hhh', 'yyy', 'NOC', 12, 2374, 28488, 28488),
(6, 6, '2025-03-13', 'dimpal', 1, 'jjj', 'jjj', 'jj', 5, 111, 555, 555),
(7, 22, '2025-03-13', 'riddhi', 2, 'kkk', 'uu', 'huu', 7, 798, 5586, 5586),
(8, 8, '2025-03-13', 'dimpal', 1, 'ttt', 'tt', 'tty', 12, 677, 8124, 8124),
(9, 62, '2023-03-25', 'khushi', 1, 'cc', 'cc', 'cc', 6, 99, 594, 594),
(11, 11, '2025-03-27', 'BRIO SOFT', 1, 'kkk', 'uu', 'huu', 2, 798, 1596, 1596),
(107, 56, '2023-01-25', 'khushi', 1, 'kk', 'kk', 'NOC', 77, 77, 5929, 5929),
(129, 30, '0002-05-25', 'bhakti', 1, 'dd', 'fg', 'hh', 88, 77, 6776, 6776);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `Bsno` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Add1` varchar(255) NOT NULL,
  `Add2` varchar(255) NOT NULL,
  `City` varchar(100) NOT NULL,
  `Pincode` varchar(10) NOT NULL,
  `State` varchar(100) NOT NULL,
  `Mobileno` varchar(10) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `GSTno` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`Bsno`, `Name`, `Add1`, `Add2`, `City`, `Pincode`, `State`, `Mobileno`, `Email`, `GSTno`) VALUES
(4, 'vrund ', 'aaa', 'aaaa', 'surat', '293898', 'JAMMU AND KASHMIR', '9273217388', 'dsj@g.com', 'wdh'),
(6, 'khushi', 'manjalpur', 'manjlpur', 'vafodara', '832877', 'ARUNACHAL PRADESH', '2347824789', 'hd@g.com', 'jdk'),
(9, 'dimpal', 'gotri', 'ff', 'vadodara', '766555', 'DAMAN AND DIV', '9273821777', 'dgu@g.com', 'ehu328'),
(12, 'BRIO SOFT', 'PRANAM COMPLEX,', 'AKOTA,', 'VADOARA', '390007', 'GUJARAT', '7016112345', 'brio@soft.in', '24AGZPP11221ZM'),
(13, 'bhakti', 'kapurai', 'kpurau', 'vadodara', '667666', 'BIHAR', '3746842999', 'dg@g.com', 'edh'),
(14, 'riddhi', 'halol', 'halol', 'vadodar', '721387', 'BIHAR', '7236826889', 'swg@g.com', 'jsj'),
(15, 'jj', 'jj', 'jj', 'jj', '788888', 'ASSAM', '6666666666', 'gy@g.com', 'gyu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`Bsno`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`Bsno`),
  ADD UNIQUE KEY `Codeno` (`Codeno`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`BSno`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `somst`
--
ALTER TABLE `somst`
  ADD PRIMARY KEY (`Bsno`),
  ADD UNIQUE KEY `Ordno_2` (`Ordno`),
  ADD KEY `Ordno` (`Ordno`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`Bsno`),
  ADD UNIQUE KEY `Mobileno` (`Mobileno`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `GSTno` (`GSTno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `Bsno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `Bsno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `BSno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `somst`
--
ALTER TABLE `somst`
  MODIFY `Bsno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `Bsno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
